## AI-Powered Security Analyst Platform

SecurityAI Labs is building AI agents that assist cybersecurity teams with vulnerability assessment, security monitoring, incident investigation, compliance review, and security reporting.

Our mission is to reduce repetitive security work so security teams can focus on high-value activities.

## Problem

Security teams are overwhelmed by:

- Growing numbers of vulnerabilities
- Large volumes of security logs
- Manual incident triage
- Complex compliance requirements
- Limited cybersecurity resources

## First Product: Pentest Findings Analyst (MVP)

Pentest and scanner reports arrive in different formats, with duplicates and inconsistent severity ratings. Turning them into a remediation plan and a management summary takes hours of manual work.

The **Pentest Findings Analyst** does it in minutes:

| Step | What it does |
|---|---|
| 1. Ingest | Reads CSV, Excel, JSON, PDF or TXT reports |
| 2. Normalize | Extracts findings into one standard schema |
| 3. Classify | Assigns severity (CVSS v3.1), CWE and OWASP Top 10 2021 |
| 4. Deduplicate | Merges the same issue reported on the same asset |
| 5. Prioritize | Sorts by severity and CVSS score |
| 6. Report | Exports an Excel remediation tracker and an executive summary |

Two modes:

- **Claude AI mode** – Claude extracts findings from unstructured reports, explains severity and writes the executive summary.
- **Offline mode** – a deterministic rule engine (CVSS + keyword rules), with no API key needed.

## Quick Start

```bash
git clone https://github.com/alexnguyenn2712-coder/security-ai-labs.git
cd security-ai-labs
pip install -r requirements.txt
cp .env.example .env        # add your ANTHROPIC_API_KEY (optional)

# Web UI
streamlit run app/streamlit_app.py

# Command line
python cli.py samples/sample_findings.csv
```

Outputs: `output/findings_tracker.xlsx` and `output/executive_summary.md`.

## Project Structure

```text
agents/      Claude agent + prompts
core/        Finding model, severity scoring, deduplication
parsers/     CSV / Excel / JSON / PDF / TXT loaders
exporters/   Excel tracker + Markdown summary
app/         Streamlit web UI
samples/     Fictional sample data
tests/       Unit tests (run: python -m pytest)
docs/        Roadmap
```

## Roadmap

- **v0.1** – Pentest Findings Analyst (current)
- **v0.2** – PowerPoint executive report, retest tracking
- **v0.3** – AD / Windows event analyzer
- **v0.4** – Security baseline compliance checker
- **v1.0** – AI Security Analyst workspace

See [docs/ROADMAP.md](docs/ROADMAP.md).

## Data Handling

Sample data in this repository is fictional. Only use sanitized data with the public demo. API keys are loaded from `.env`, which must never be committed.

## Technology

- Claude (Anthropic)
- Python, Streamlit, pandas, openpyxl
- AI Agents
- Security Knowledge Base (CWE, OWASP, CVSS)

## Vision

Make enterprise-grade cybersecurity expertise accessible to organizations of all sizes through AI.

## Contact

**Founder:** Nguyen Viet Anh  
**Location:** Hanoi, Vietnam
