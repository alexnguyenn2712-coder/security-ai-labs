"""Export an executive summary as Markdown."""
from __future__ import annotations

from core.models import Finding


def to_markdown(findings: list[Finding], summary: dict) -> str:
    lines = ["# Pentest Executive Summary", "", f"**Overall risk:** {summary.get('overall_risk', '')}", ""]
    lines += ["## Findings by severity", "", "| Severity | Count |", "|---|---|"]
    for sev, n in summary.get("stats", {}).items():
        lines.append(f"| {sev} | {n} |")
    lines += ["", "## Key points", ""] + [f"- {b}" for b in summary.get("bullets", [])]
    lines += ["", "## Priority actions", ""] + [f"{i}. {a}" for i, a in
                                                enumerate(summary.get("priority_actions", []), 1)]
    lines += ["", "## Findings", "", "| ID | Severity | CVSS | Title | Asset | CWE |", "|---|---|---|---|---|---|"]
    for i, f in enumerate(findings, 1):
        lines.append(f"| F-{i:03d} | {f.severity} | {f.cvss or '-'} | {f.title} | {f.asset} | {f.cwe} |")
    return "\n".join(lines) + "\n"
