"""Export findings to a remediation-tracking Excel workbook."""
from __future__ import annotations

import io

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation

from core.models import Finding, SEVERITY_ORDER

COLORS = {"Critical": "C00000", "High": "FF6600", "Medium": "FFC000", "Low": "70AD47", "Info": "A6A6A6"}
COLUMNS = ["ID", "Severity", "CVSS", "Title", "Asset", "CWE", "OWASP", "Description",
           "Evidence", "Recommendation", "Rationale", "Owner", "Status", "Target Date", "Duplicates"]


def to_excel(findings: list[Finding], summary: dict) -> bytes:
    wb = Workbook()

    # --- Summary sheet ---
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = "Pentest Findings - Executive Summary"
    ws["A1"].font = Font(bold=True, size=14)
    ws["A3"], ws["B3"] = "Severity", "Count"
    for c in ("A3", "B3"):
        ws[c].font = Font(bold=True)
    for i, sev in enumerate(SEVERITY_ORDER, start=4):
        ws.cell(row=i, column=1, value=sev).fill = PatternFill("solid", fgColor=COLORS[sev])
        ws.cell(row=i, column=1).font = Font(bold=True, color="FFFFFF")
        ws.cell(row=i, column=2, value=f'=COUNTIF(Findings!B:B,"{sev}")')
    ws.cell(row=9, column=1, value="Total").font = Font(bold=True)
    ws.cell(row=9, column=2, value="=SUM(B4:B8)").font = Font(bold=True)
    ws["A11"] = "Overall risk"
    ws["A11"].font = Font(bold=True)
    ws["B11"] = summary.get("overall_risk", "")
    r = 13
    ws.cell(row=r, column=1, value="Priority actions").font = Font(bold=True)
    for a in summary.get("priority_actions", []):
        r += 1
        ws.cell(row=r, column=1, value="•")
        ws.cell(row=r, column=2, value=a)
    ws.column_dimensions["A"].width = 18
    ws.column_dimensions["B"].width = 90

    # --- Findings sheet ---
    fs = wb.create_sheet("Findings")
    fs.append(COLUMNS)
    for cell in fs[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F3864")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for idx, f in enumerate(findings, start=1):
        fs.append([f"F-{idx:03d}", f.severity, f.cvss, f.title, f.asset, f.cwe, f.owasp, f.description,
                   f.evidence, f.recommendation, f.ai_rationale, f.owner, f.status, "", ", ".join(f.duplicates)])
        sev_cell = fs.cell(row=idx + 1, column=2)
        sev_cell.fill = PatternFill("solid", fgColor=COLORS.get(f.severity, "A6A6A6"))
        sev_cell.font = Font(bold=True, color="FFFFFF")
    widths = [8, 11, 7, 40, 28, 11, 30, 50, 35, 45, 40, 15, 13, 13, 25]
    for i, w in enumerate(widths):
        fs.column_dimensions[chr(65 + i)].width = w
    for row in fs.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(vertical="top", wrap_text=True)
    dv = DataValidation(type="list", formula1='"Open,In Progress,Fixed,Retest,Accepted Risk"', allow_blank=True)
    fs.add_data_validation(dv)
    dv.add(f"M2:M{max(len(findings) + 1, 2)}")
    fs.freeze_panes = "A2"
    fs.auto_filter.ref = fs.dimensions

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
