"""Load findings from CSV / Excel / JSON / PDF / TXT into Finding objects."""
from __future__ import annotations

import io
import json
from pathlib import Path

import pandas as pd

from core.models import Finding

# Flexible column aliases found in common scanner / pentest exports
ALIASES = {
    "title": ["title", "name", "finding", "vulnerability", "issue", "plugin name"],
    "description": ["description", "details", "synopsis", "summary"],
    "asset": ["asset", "host", "url", "target", "endpoint", "ip"],
    "severity": ["severity", "risk", "rating", "priority"],
    "cvss": ["cvss", "cvss score", "cvss_score", "cvss v3", "score"],
    "cwe": ["cwe", "cwe id"],
    "evidence": ["evidence", "proof", "poc", "output"],
    "recommendation": ["recommendation", "remediation", "solution", "fix"],
}


def _pick(row: dict, field: str) -> str:
    lower = {str(k).strip().lower(): v for k, v in row.items()}
    for alias in ALIASES[field]:
        if alias in lower and pd.notna(lower[alias]) and str(lower[alias]).strip():
            return str(lower[alias]).strip()
    return ""


def _to_float(v: str) -> float | None:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def rows_to_findings(rows: list[dict], source: str) -> list[Finding]:
    findings = []
    for row in rows:
        title = _pick(row, "title")
        if not title:
            continue
        sev = _pick(row, "severity").capitalize() or "Info"
        findings.append(Finding(
            title=title,
            description=_pick(row, "description"),
            asset=_pick(row, "asset"),
            severity=sev,
            cvss=_to_float(_pick(row, "cvss")),
            cwe=_pick(row, "cwe"),
            evidence=_pick(row, "evidence"),
            recommendation=_pick(row, "recommendation"),
            source=source,
        ))
    return findings


def extract_pdf_text(data: bytes) -> str:
    from pypdf import PdfReader
    reader = PdfReader(io.BytesIO(data))
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def load_file(name: str, data: bytes) -> tuple[list[Finding], str]:
    """Return (structured findings, raw_text). Unstructured files return raw text for the AI agent."""
    ext = Path(name).suffix.lower()
    if ext == ".csv":
        df = pd.read_csv(io.BytesIO(data))
        return rows_to_findings(df.to_dict("records"), name), ""
    if ext in (".xlsx", ".xls"):
        df = pd.read_excel(io.BytesIO(data))
        return rows_to_findings(df.to_dict("records"), name), ""
    if ext == ".json":
        obj = json.loads(data.decode("utf-8"))
        rows = obj.get("findings", obj) if isinstance(obj, dict) else obj
        return rows_to_findings(rows, name), ""
    if ext == ".pdf":
        return [], extract_pdf_text(data)
    if ext in (".txt", ".md"):
        return [], data.decode("utf-8", errors="ignore")
    raise ValueError(f"Unsupported file type: {ext}")
