"""Pentest Findings Analyst - Claude-powered with offline rule-based fallback."""
from __future__ import annotations

import json
import os
import re
from collections import Counter

from agents.prompts import SYSTEM_PROMPT, EXTRACT_PROMPT, ENRICH_PROMPT, SUMMARY_PROMPT
from core.dedup import deduplicate
from core.models import Finding, SEVERITY_ORDER
from core.scoring import classify, severity_from_cvss

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


class FindingsAnalyst:
    def __init__(self, api_key: str | None = None, model: str | None = None):
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        self.model = model or os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5")
        self.client = None
        if self.api_key:
            import anthropic
            self.client = anthropic.Anthropic(api_key=self.api_key)

    @property
    def ai_enabled(self) -> bool:
        return self.client is not None

    # ---------- Claude helpers ----------
    def _ask(self, prompt: str, max_tokens: int = 4000) -> dict:
        msg = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
        )
        text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
        text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
        return json.loads(text)

    # ---------- Pipeline ----------
    def extract_from_text(self, text: str, source: str = "report") -> list[Finding]:
        if not self.ai_enabled:
            raise RuntimeError("Unstructured (PDF/TXT) parsing requires ANTHROPIC_API_KEY.")
        data = self._ask(EXTRACT_PROMPT.format(text=text[:150_000]), max_tokens=8000)
        return [Finding(source=source, **{k: v for k, v in f.items() if k in Finding.__dataclass_fields__})
                for f in data.get("findings", [])]

    def enrich(self, findings: list[Finding]) -> list[Finding]:
        # Always run rule engine first (deterministic baseline)
        findings = [classify(f) for f in findings]
        if not self.ai_enabled or not findings:
            return findings
        payload = [{"index": i, "title": f.title, "description": f.description[:800],
                    "asset": f.asset, "cvss": f.cvss, "evidence": f.evidence[:400]}
                   for i, f in enumerate(findings)]
        data = self._ask(ENRICH_PROMPT.format(findings=json.dumps(payload, ensure_ascii=False)))
        for r in data.get("results", []):
            i = r.get("index")
            if i is None or i >= len(findings):
                continue
            f = findings[i]
            if f.cvss is None and isinstance(r.get("cvss"), (int, float)):
                f.cvss = float(r["cvss"])
            # Provided CVSS wins over AI opinion; otherwise accept AI severity
            f.severity = severity_from_cvss(f.cvss) or r.get("severity", f.severity)
            f.cwe = r.get("cwe") or f.cwe
            f.owasp = r.get("owasp") or f.owasp
            f.ai_rationale = r.get("rationale") or f.ai_rationale
            f.recommendation = f.recommendation or r.get("recommendation", "")
        return findings

    def summarize(self, findings: list[Finding]) -> dict:
        stats = {s: 0 for s in SEVERITY_ORDER}
        stats.update(Counter(f.severity for f in findings))
        top = sorted(findings, key=lambda f: (f.severity_rank, -(f.cvss or 0)))[:10]

        if self.ai_enabled and findings:
            lines = "\n".join(f"- [{f.severity}] {f.title} on {f.asset}" for f in top)
            result = self._ask(SUMMARY_PROMPT.format(stats=stats, findings=lines), max_tokens=1500)
            result["stats"] = stats
            return result

        # Offline summary
        crit_high = stats["Critical"] + stats["High"]
        overall = ("High" if stats["Critical"] else "Elevated" if stats["High"] else
                   "Moderate" if stats["Medium"] else "Low")
        return {
            "overall_risk": f"{overall} - {crit_high} Critical/High findings out of {len(findings)} total.",
            "bullets": [f"{s}: {n}" for s, n in stats.items() if n],
            "priority_actions": [f"Fix '{f.title}' on {f.asset or 'N/A'}" for f in top[:3]],
            "stats": stats,
        }

    def run(self, findings: list[Finding], raw_text: str = "", source: str = "") -> tuple[list[Finding], dict]:
        if raw_text:
            findings = findings + self.extract_from_text(raw_text, source)
        findings = self.enrich(findings)
        findings = deduplicate(findings)
        findings.sort(key=lambda f: (f.severity_rank, -(f.cvss or 0)))
        return findings, self.summarize(findings)
