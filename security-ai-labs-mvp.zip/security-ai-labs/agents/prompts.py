"""Prompts for the Pentest Findings Analyst agent."""

SYSTEM_PROMPT = """You are a senior penetration-testing analyst and security report reviewer.
You normalize findings, assess severity with CVSS v3.1 reasoning, map to CWE and OWASP Top 10 2021,
and write concise, factual output. Never invent CVE IDs. If evidence is insufficient, say so.
Always answer with valid JSON only, no markdown fences."""

EXTRACT_PROMPT = """Extract every security finding from the pentest report text below.
Return JSON: {{"findings": [{{"title": str, "description": str, "asset": str,
"cvss": number|null, "evidence": str, "recommendation": str}}]}}

REPORT TEXT:
<<<
{text}
>>>"""

ENRICH_PROMPT = """Review these normalized findings. For each, return the same index with:
severity (Critical|High|Medium|Low|Info), cvss (number, estimate if missing),
cwe (e.g. CWE-89), owasp (e.g. A03:2021-Injection), rationale (1 sentence, why this severity),
recommendation (1-2 sentences, concrete fix).
Return JSON: {{"results": [{{"index": int, "severity": str, "cvss": number, "cwe": str,
"owasp": str, "rationale": str, "recommendation": str}}]}}

FINDINGS:
{findings}"""

SUMMARY_PROMPT = """Write an executive summary for management (non-technical) of this pentest.
Max 5 bullet points + 1 overall risk statement. Mention counts by severity, top risks in business terms,
and the 3 priority actions. Return JSON: {{"overall_risk": str, "bullets": [str], "priority_actions": [str]}}

STATS: {stats}
TOP FINDINGS:
{findings}"""
