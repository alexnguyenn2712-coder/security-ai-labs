from pathlib import Path

from agents.findings_analyst import FindingsAnalyst
from core.models import Finding
from core.scoring import classify, severity_from_cvss
from exporters.excel import to_excel
from parsers.loader import load_file

SAMPLE = Path(__file__).resolve().parents[1] / "samples" / "sample_findings.csv"


def test_cvss_mapping():
    assert severity_from_cvss(9.8) == "Critical"
    assert severity_from_cvss(7.0) == "High"
    assert severity_from_cvss(5.3) == "Medium"
    assert severity_from_cvss(2.0) == "Low"
    assert severity_from_cvss(None) is None


def test_rule_classification():
    f = classify(Finding(title="SQL Injection in search"))
    assert f.cwe == "CWE-89" and f.severity == "Critical"


def test_offline_pipeline_dedup_and_sort():
    findings, raw = load_file(SAMPLE.name, SAMPLE.read_bytes())
    assert len(findings) == 10 and raw == ""
    analyst = FindingsAnalyst(api_key="")
    analyst.client = None
    result, summary = analyst.run(findings)
    assert len(result) == 9  # one duplicate merged
    assert result[0].severity == "Critical"
    assert summary["stats"]["Critical"] >= 1
    assert to_excel(result, summary)[:2] == b"PK"
