"""Core data model for a normalized security finding."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict

SEVERITY_ORDER = ["Critical", "High", "Medium", "Low", "Info"]


@dataclass
class Finding:
    title: str
    description: str = ""
    asset: str = ""
    severity: str = "Info"
    cvss: float | None = None
    cwe: str = ""
    owasp: str = ""
    evidence: str = ""
    recommendation: str = ""
    owner: str = ""
    status: str = "Open"
    source: str = ""
    ai_rationale: str = ""
    duplicates: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["duplicates"] = ", ".join(self.duplicates)
        return d

    @property
    def severity_rank(self) -> int:
        try:
            return SEVERITY_ORDER.index(self.severity)
        except ValueError:
            return len(SEVERITY_ORDER)
