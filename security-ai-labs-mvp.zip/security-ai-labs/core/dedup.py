"""Group duplicate findings (same issue reported on the same asset)."""
from __future__ import annotations

import re
from difflib import SequenceMatcher

from core.models import Finding


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]", "", s.lower()).strip()


def deduplicate(findings: list[Finding], threshold: float = 0.85) -> list[Finding]:
    """Merge findings with near-identical titles on the same asset. Keeps the most severe."""
    result: list[Finding] = []
    for f in sorted(findings, key=lambda x: x.severity_rank):
        for kept in result:
            same_asset = _norm(kept.asset) == _norm(f.asset)
            similar = SequenceMatcher(None, _norm(kept.title), _norm(f.title)).ratio() >= threshold
            if same_asset and similar:
                kept.duplicates.append(f.title)
                break
        else:
            result.append(f)
    return result
