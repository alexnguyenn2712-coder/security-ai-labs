"""Rule-based severity + CWE/OWASP mapping (offline fallback when no API key)."""
from __future__ import annotations

from core.models import Finding

# keyword -> (CWE, OWASP Top 10 2021, default severity)
RULES: list[tuple[tuple[str, ...], str, str, str]] = [
    (("remote code execution", "rce", "command injection", "os command"), "CWE-78", "A03:2021-Injection", "Critical"),
    (("sql injection", "sqli"), "CWE-89", "A03:2021-Injection", "Critical"),
    (("deserialization",), "CWE-502", "A08:2021-Software and Data Integrity Failures", "Critical"),
    (("idor", "insecure direct object", "broken access", "privilege escalation", "authorization bypass"),
     "CWE-639", "A01:2021-Broken Access Control", "High"),
    (("authentication bypass", "weak password", "default credential", "brute force", "no lockout"),
     "CWE-287", "A07:2021-Identification and Authentication Failures", "High"),
    (("ssrf", "server-side request"), "CWE-918", "A10:2021-Server-Side Request Forgery", "High"),
    (("xss", "cross-site scripting"), "CWE-79", "A03:2021-Injection", "Medium"),
    (("csrf", "cross-site request forgery"), "CWE-352", "A01:2021-Broken Access Control", "Medium"),
    (("outdated", "vulnerable component", "end of life", "eol", "unpatched"),
     "CWE-1104", "A06:2021-Vulnerable and Outdated Components", "Medium"),
    (("tls", "ssl", "cipher", "cleartext", "unencrypted"), "CWE-319", "A02:2021-Cryptographic Failures", "Medium"),
    (("security header", "clickjacking", "x-frame-options", "content-security-policy", "hsts"),
     "CWE-693", "A05:2021-Security Misconfiguration", "Low"),
    (("information disclosure", "verbose error", "stack trace", "version disclosure", "directory listing"),
     "CWE-200", "A05:2021-Security Misconfiguration", "Low"),
]


def severity_from_cvss(score: float | None) -> str | None:
    """CVSS v3.x qualitative rating."""
    if score is None:
        return None
    if score >= 9.0:
        return "Critical"
    if score >= 7.0:
        return "High"
    if score >= 4.0:
        return "Medium"
    if score > 0.0:
        return "Low"
    return "Info"


def classify(finding: Finding) -> Finding:
    """Fill severity / CWE / OWASP using CVSS first, then keyword rules."""
    text = f"{finding.title} {finding.description}".lower()
    matched = None
    for keywords, cwe, owasp, sev in RULES:
        if any(k in text for k in keywords):
            matched = (cwe, owasp, sev, keywords[0])
            break

    if matched:
        finding.cwe = finding.cwe or matched[0]
        finding.owasp = finding.owasp or matched[1]

    cvss_sev = severity_from_cvss(finding.cvss)
    if cvss_sev:
        finding.severity = cvss_sev
        finding.ai_rationale = finding.ai_rationale or f"Severity derived from CVSS {finding.cvss}."
    elif matched:
        finding.severity = matched[2]
        finding.ai_rationale = finding.ai_rationale or f"Rule match on '{matched[3]}' (no CVSS provided)."
    elif finding.severity not in ("Critical", "High", "Medium", "Low", "Info"):
        finding.severity = "Info"
    return finding
