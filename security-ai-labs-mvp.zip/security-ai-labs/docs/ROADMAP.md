# Development Roadmap

## v0.1 – Pentest Findings Analyst (MVP) ✅
- [x] Multi-format ingestion (CSV, XLSX, JSON, PDF, TXT)
- [x] Normalized finding schema
- [x] CVSS v3.1 severity mapping + CWE / OWASP rule engine
- [x] Claude enrichment (severity rationale, recommendations)
- [x] Claude extraction from unstructured reports
- [x] Duplicate merging
- [x] Excel remediation tracker + Markdown executive summary
- [x] Streamlit UI + CLI
- [x] Unit tests + GitHub Actions CI

## v0.2 – Reporting
- [ ] PowerPoint executive report export
- [ ] Retest workflow (compare two reports: fixed / still open / new)
- [ ] Owner assignment and SLA by severity
- [ ] Demo video and hosted demo

## v0.3 – AD Event Analyzer
- [ ] Parse Windows Security events (e.g. 2889, 4625, 4740, 4728)
- [ ] Root cause and risk explanation
- [ ] Recommended response actions

## v0.4 – Baseline Compliance Checker
- [ ] Compare configuration exports against a control catalog
- [ ] Evidence gap report

## v1.0 – AI Security Analyst Workspace
- [ ] Multi-agent workflow (triage → investigate → report)
- [ ] Integrations (SIEM, ticketing)
- [ ] Role-based access, audit log
