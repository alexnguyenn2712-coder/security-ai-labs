"""Command-line entry point.

Usage:
    python cli.py samples/sample_findings.csv
    python cli.py report.pdf --out output/
"""
from __future__ import annotations

import argparse
from pathlib import Path

from agents.findings_analyst import FindingsAnalyst
from exporters.excel import to_excel
from exporters.markdown import to_markdown
from parsers.loader import load_file


def main() -> None:
    ap = argparse.ArgumentParser(description="SecurityAI Labs - Pentest Findings Analyst")
    ap.add_argument("file", help="CSV / XLSX / JSON / PDF / TXT report")
    ap.add_argument("--out", default="output", help="Output folder")
    args = ap.parse_args()

    path = Path(args.file)
    findings, raw = load_file(path.name, path.read_bytes())
    analyst = FindingsAnalyst()
    print(f"[i] Mode: {'Claude AI' if analyst.ai_enabled else 'Offline rule engine'}")

    findings, summary = analyst.run(findings, raw, path.name)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "findings_tracker.xlsx").write_bytes(to_excel(findings, summary))
    (out / "executive_summary.md").write_text(to_markdown(findings, summary), encoding="utf-8")

    print(f"[+] {len(findings)} findings | {summary['overall_risk']}")
    for f in findings:
        print(f"    [{f.severity:<8}] {f.title} ({f.asset})")
    print(f"[+] Saved to {out.resolve()}")


if __name__ == "__main__":
    main()
