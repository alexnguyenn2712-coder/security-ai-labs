"""Streamlit UI: streamlit run app/streamlit_app.py"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import streamlit as st

from agents.findings_analyst import FindingsAnalyst
from core.models import SEVERITY_ORDER
from exporters.excel import to_excel
from exporters.markdown import to_markdown
from parsers.loader import load_file

st.set_page_config(page_title="SecurityAI Labs - Findings Analyst", page_icon="🛡️", layout="wide")
st.title("🛡️ SecurityAI Labs — Pentest Findings Analyst")
st.caption("Upload a pentest / scanner report → normalized, prioritized findings + executive summary.")

with st.sidebar:
    st.header("Settings")
    api_key = st.text_input("Anthropic API key (optional)", type="password",
                            help="Leave empty to use the offline rule engine.")
    model = st.text_input("Claude model", value="claude-sonnet-4-5")
    st.info("⚠️ Use sanitized or sample data only. Do not upload confidential reports to public demos.")

uploaded = st.file_uploader("Report file", type=["csv", "xlsx", "json", "pdf", "txt"])
use_sample = st.button("Try with sample data")

if uploaded or use_sample:
    if use_sample:
        p = Path(__file__).resolve().parents[1] / "samples" / "sample_findings.csv"
        name, data = p.name, p.read_bytes()
    else:
        name, data = uploaded.name, uploaded.getvalue()

    analyst = FindingsAnalyst(api_key=api_key or None, model=model)
    st.write(f"Mode: **{'Claude AI' if analyst.ai_enabled else 'Offline rule engine'}**")

    try:
        with st.spinner("Analyzing findings..."):
            findings, raw = load_file(name, data)
            findings, summary = analyst.run(findings, raw, name)
    except Exception as e:  # noqa: BLE001
        st.error(f"Analysis failed: {e}")
        st.stop()

    stats = summary["stats"]
    cols = st.columns(len(SEVERITY_ORDER))
    for c, sev in zip(cols, SEVERITY_ORDER):
        c.metric(sev, stats.get(sev, 0))

    st.subheader("Executive summary")
    st.markdown(f"**Overall risk:** {summary['overall_risk']}")
    for b in summary.get("bullets", []):
        st.markdown(f"- {b}")
    st.markdown("**Priority actions**")
    for i, a in enumerate(summary.get("priority_actions", []), 1):
        st.markdown(f"{i}. {a}")

    st.subheader("Findings")
    df = pd.DataFrame([f.to_dict() for f in findings])
    st.dataframe(df[["severity", "cvss", "title", "asset", "cwe", "owasp", "ai_rationale", "duplicates"]],
                 width="stretch", hide_index=True)

    c1, c2 = st.columns(2)
    c1.download_button("⬇️ Excel tracker", to_excel(findings, summary), "findings_tracker.xlsx")
    c2.download_button("⬇️ Executive summary (MD)", to_markdown(findings, summary), "executive_summary.md")
